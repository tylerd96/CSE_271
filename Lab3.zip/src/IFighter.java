
public interface IFighter {
	
	public void attack(IFighter opp);
}
