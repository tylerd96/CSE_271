
public class Passenger extends Person {

	public Passenger(String fName, String lName) {
		super(fName, lName);
	}

}
