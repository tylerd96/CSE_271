

public class SmallShip extends Ship {

	public SmallShip(String shipName, ShipType shipType) {
		super(shipName, shipType);
	}

}
